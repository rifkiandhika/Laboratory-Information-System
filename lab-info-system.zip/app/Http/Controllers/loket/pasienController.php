<?php

namespace App\Http\Controllers\loket;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\departement;
use App\Models\icd10;
use App\Models\pemeriksaan;
use App\Models\pemeriksaan_pasien;
use App\Models\pasien;


use Illuminate\Support\Facades\DB;

use Alert;
use App\Models\historyPasien;
use App\Models\pasienLab;
use App\Models\pembayaran;
use App\Models\tabung;

class pasienController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        // ambil semua data pasien cito yang belum dilayani
        $data_pasien_cito = pasien::where('cito', 1)->where('status', 'Belum Dilayani')->get();
        $data_pasien = pasien::where('cito', 0)->where('status', 'Belum Dilayani')->get();
        $data_pemeriksaan_pasien = pemeriksaan_pasien::all();

        $data_departement = departement::all();
        $data_pemeriksaan = pemeriksaan::all();

        //sweet alert
        $title = 'Menghapus data Pasien!';
        $text = "Anda yakin untuk menghapus data ini?";
        confirmDelete($title, $text);

        return view('loket.index', compact('data_pasien', 'data_pasien_cito', 'data_pemeriksaan_pasien', 'data_departement', 'data_pemeriksaan'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //membuat nomor lab secara otomatis dengan format: LAB-tanggal-bulan-tahun-urutan (misal: LAB010121001) dan berulang jika tanggal berbeda
        $tanggal = date('dmy');
        $urutan = pasien::where('no_lab', 'like', 'LAB'.$tanggal.'%')->count()+1;

        //ubah format urutan menjadi 3 digit (misal: 001)
        $urutan = sprintf("%03d", $urutan);
        $no_lab = 'LAB'.$tanggal.$urutan;

        $data_departement = departement::all();
        $data_pemeriksaan = pemeriksaan::all();

        // dd($data_departement);

        return view('loket.tambah-pasien', compact('no_lab', 'data_departement', 'data_pemeriksaan'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //jika cito di centang, maka simpan data cito dengan 1
        if($request->cito)
        {
            $cito = 1;
        }
        else
        {
            $cito = 0;
        }

        $harga = str_replace('.', '', $request->hargapemeriksaan);

        $harga = (int)$harga;

        //pisah pemeriksaan
        foreach($request->pemeriksaan as $pemeriksaan)
        {
            //pisa pemeriksaan berdasarkan tanda koma
            $pemeriksaan_temp = explode(',', $pemeriksaan);

            //ambil id departement dari pemeriksaan
            $id_departement[] = $pemeriksaan_temp[0];

            //ambil nama parameter dari pemeriksaan
            $nama_parameter[] = $pemeriksaan_temp[1];
        }

        //simpan data pasien
        pasien::create([
            'no_lab' => $request->nolab,
            'no_rm' => $request->norm,
            'cito' => $cito,
            'nik' => $request->nik,
            'jenis_pelayanan' => $request->jenispelayanan,
            'nama' => $request->nama,
            'lahir' => $request->tanggallahir,
            'jenis_kelamin' => $request->jeniskelamin,
            'no_telp' => $request->notelepon,
            'kode_dokter' => $request->dokter,
            'asal_ruangan' => '-',
            'diagnosa' => $request->diagnosa,
            'tanggal_masuk' => now(),
            'alamat' => $request->alamat,
        ]);

        //simpan data pemeriksaan pasien dengan looping
        $no = 0;
        foreach($request->pemeriksaan as $pemeriksaan)
        {
            //kirim data pemeriksaan pasien ke database
            DB::table('pemeriksaan_pasiens')->insert([
                'no_lab' => $request->nolab,
                'id_departement' => $id_departement[$no],
                'nama_parameter' => $nama_parameter[$no],
                'harga' => $harga,
                'created_at' => now(),
                'updated_at' => now(),
            ]);

            $no++;
        }

        //simpan history pasien
        historyPasien::create([
            'no_lab' => $request->nolab,
            'proses' => 'Order',
            'tempat' => 'Loket',
            'waktu_proses' => now(),
        ]);

        //return with sweet alert
        toast('Berhasil Menambah data pasien','success');
        return redirect()->route('pasien.index');
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $lab)
    {
        // dd($request->all());

        $harga = str_replace('.', '', $request->hargapemeriksaan);

        $harga = (int)$harga;

        //update data pasien
        pasien::where('no_lab', $request->nolab)->update([
            'nik' => $request->nik,
            'jenis_pelayanan' => $request->jenis_pelayanan,
            'nama' => $request->nama,
            'lahir' => $request->tanggal_lahir,
            'jenis_kelamin' => $request->jenis_kelamin,
            'no_telp' => $request->no_telepon,
            'kode_dokter' => $request->dokter,
            'asal_ruangan' => $request->ruangan,
            'diagnosa' => $request->diagnosa,
            'tanggal_masuk' => now(),
            'alamat' => $request->alamat,
        ]);

        //truncate data pemeriksaan pasien
        pemeriksaan_pasien::where('no_lab', $request->nolab)->delete();

        //create data pemeriksaan pasien
        foreach($request->pemeriksaan as $pemeriksaan)
        {
            //pisa pemeriksaan berdasarkan tanda koma
            $pemeriksaan_temp = explode(',', $pemeriksaan);

            //ambil id departement dari pemeriksaan
            $id_departement[] = $pemeriksaan_temp[0];

            //ambil nama parameter dari pemeriksaan
            $nama_parameter[] = $pemeriksaan_temp[1];
        }

        //simpan data pemeriksaan pasien dengan looping
        $no = 0;
        foreach($request->pemeriksaan as $pemeriksaan)
        {
            //kirim data pemeriksaan pasien ke database
            DB::table('pemeriksaan_pasiens')->insert([
                'no_lab' => $request->nolab,
                'id_departement' => $id_departement[$no],
                'nama_parameter' => $nama_parameter[$no],
                'harga' => $harga,
                'created_at' => now(),
                'updated_at' => now(),
            ]);

            $no++;
        }

        //ubah history pasien
        historyPasien::where('no_lab', $request->nolab)->update([
            'waktu_proses' => now(),
        ]);

        toast('Berhasil mengubah data pasien','success');
        return redirect()->route('pasien.index');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        // dd($id);
        pasien::where('no_lab', $id)->delete();
        pemeriksaan_pasien::where('no_lab', $id)->delete();
        pembayaran::where('no_lab', $id)->delete();

        toast('Berhasil menghapus data pasien','success');
        return redirect()->route('pasien.index');
    }

    public function getIcd10(Request $request)
    {
        if($request->get('query'))
        {
            $query = $request->get('query');
            $data = icd10::where('code', 'LIKE', "%{$query}%")->orWhere('name_id', 'LIKE', "%{$query}%")->get();
            $output = '<ul class="dropdown-menu diagnosa-auto" style="display:block; position:absolute">';
            foreach($data as $row)
            {
                $output .= '
                <li><a href="#">'.$row->code.' '.$row->name_id.'</a></li>
                ';
            }
            $output .= '</ul>';
            echo $output;
        }
    }

    public function getDataPasien($lab)
    {
        $data_pasien = pasien::where('no_lab', $lab)->first();
        $data_pemeriksaan_pasien = pemeriksaan_pasien::where('no_lab', $lab)->get();
        $id_departement_pasien = pemeriksaan_pasien::where('no_lab', $lab)->distinct()->get(['id_departement']);
        $icd10 = icd10::all();
        $data_departement = departement::all();
        $data_pemeriksaan = pemeriksaan::all();
        $history_pasien = historyPasien::where('no_lab', $lab)->where('proses', 'Disetujui oleh analis lab')->get();
        $dataTabung = tabung::all();

        if($data_pasien)
        {
            return response()->json([
                'success' => true,
                'message' => 'Data pasien ditemukan',
                'data_pasien' => $data_pasien,
                'data_pemeriksaan_pasien' => $data_pemeriksaan_pasien,
                'id_departement_pasien' => $id_departement_pasien,
                'icd10' => $icd10,
                'data_departement' => $data_departement,
                'data_pemeriksaan' => $data_pemeriksaan,
                'history_pasien' => $history_pasien,
                'dataTabung' => $dataTabung,
            ], 200);
        }
        else
        {
            return response()->json([
                'success' => false,
                'message' => 'Data pasien tidak ditemukan',
            ], 404);
        }
    }

    public function kirimLab(Request $request){
        // dd($request->all());
        $data_pasien = pasien::where('no_lab', $request->nolab)->first();

        //update status pasien menjadi Telah Dikirim ke Lab
        pasien::where('no_lab', $request->no_lab)->update([
            'status' => 'Telah Dikirim ke Lab',
        ]);

        //simpan data pembayaran
        DB::table('pembayarans')->insert([
            'no_lab' => $request->no_lab,
            'metode_pembayaran' => $request->jenispelayanan,
            'total_pembayaran' => $request->hargapemeriksaan,
            'jumlah_bayar' => $request->jumlahbayar,
            'kembalian' => $request->kembalian,
            'tanggal_pembayaran' => now(),
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        //simpan history pasien
        historyPasien::create([
            'no_lab' => $request->no_lab,
            'proses' => 'Payment',
            'tempat' => 'Loket',
            'waktu_proses' => now(),
        ]);

        //return with sweet alert
        toast('Berhasil mengirim data pasien ke Lab','success');
        return redirect()->route('pasien.index');
    }

    public function dataPasien(){
        // mengambil data pasien selain yang belum dilayani
        $data_pasien = pasien::where('status', '!=', 'Belum Dilayani')->get();

        return view('loket.data-pasien', compact('data_pasien'));
    }
}
