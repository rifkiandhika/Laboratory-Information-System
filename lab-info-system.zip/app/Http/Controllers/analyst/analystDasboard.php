<?php

namespace App\Http\Controllers\analyst;

use App\Http\Controllers\Controller;
use App\Models\historyPasien;
use App\Models\pasien;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class analystDasboard extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //mengambil data pasien dengan 3 where, mencari status pasien yang sudah di kirim lab,  disetujui oleh analis lab, dan cito = 0
        $dataPasien = pasien::where(function($query) {
                        $query->where('status', 'Telah Dikirim ke Lab')
                            ->orWhere('status', 'Disetujui oleh analis lab');
                    })
                    ->where('cito', 0)
                    ->get();

        //mengambil data pasien dengan 3 where, mencari status pasien yang sudah di kirim lab, di setujui oleh analis lab, dan cito = 1
        $dataPasienCito = pasien::where(function($query) {
                            $query->where('status', 'Telah Dikirim ke Lab')
                                ->orWhere('status', 'Disetujui oleh analis lab');
                        })
                        ->where('cito', 1)
                        ->get();

        //mengambil data history pasien
        $dataHistory = historyPasien::where('proses', '=', 'order')->get();

        return view('analyst.main-lab', compact('dataPasien', 'dataPasienCito', 'dataHistory'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }

    public function approve(Request $request)
    {

        //mengambil data pasien berdasarkan id
        DB::table('pasiens')->where('no_lab', $request->no_lab)->update([
            'status' => 'Disetujui oleh analis lab',
        ]);

        //simpan history pasien
        DB::table('history_pasiens')->insert([
            'no_lab' => $request->no_lab,
            'proses' => 'Disetujui oleh analis lab',
            'tempat' => 'Laboratorium',
            'note' => $request->note,
            'waktu_proses' => now(),
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        //return with sweet alert
        toast('Data di setujui','success');
        return redirect()->route('analyst.index');
    }

    public function checkin(Request $request)
    {
        // dd($request->all());

        foreach($request->pilihan as $pilihan){
            // dd($pilihan);

            //mengambil data pasien berdasarkan id
            DB::table('pasiens')->where('no_lab', $pilihan)->update([
                'status' => 'Check in',
            ]);

            //simpan history pasien
            historyPasien::create([
                'no_lab' => $pilihan,
                'proses' => 'Check in',
                'tempat' => 'Laboratorium',
                'note' => $request->note,
                'waktu_proses' => now(),
            ]);
        }//end

        //return with sweet alert
        toast('Pasien telah Check in','success');
        return redirect()->route('analyst.index');
    }
}
