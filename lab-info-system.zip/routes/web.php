<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\auth\userController;
use App\Http\Controllers\icd10\icd10Controller;
use App\Http\Controllers\loket\pasienController;
use App\Http\Controllers\analyst\analystDasboard;
use App\Http\Controllers\analyst\worklistController;
use SebastianBergmann\CodeCoverage\Report\Html\Dashboard;
use App\Http\Controllers\analyst\spesimentHendlingController;


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return redirect('login');
});

//login
route::resource('login', userController::class);
route::post('login-proses', [userController::class, 'proses'])->name('login.proses');
route::get('logout', [userController::class, 'logout'])->name('logout');

route::group(['prefix' => 'demo', 'middleware' => ['auth'], 'as' => 'demo.'], function() {
    //pasien
    route::resource('pasien', pasienController::class);
    route::get('loket', [pasienController::class, 'index']);
    route::post('/pasien/kirimlab', [pasienController::class, 'kirimLab'])->name('pasien.kirimlab');
    route::get('/data-pasien', [pasienController::class, 'dataPasien'])->name('pasien.data');

    //Analyst
    route::resource('analyst', analystDasboard::class);
    route::post('analyst/setuju', [analystDasboard::class, 'approve'])->name('analyst.approve');
    route::post('analyst/checkin', [analystDasboard::class, 'checkin'])->name('analyst.checkin');

    //Spesiment Handling
    route::resource('spesiment', spesimentHendlingController::class);
    route::post('spesiment/post', [spesimentHendlingController::class, 'postSpesiment'])->name('spesiment.post');
    route::post('spesiment/checkin', [spesimentHendlingController::class, 'checkin'])->name('spesiment.checkin');

    //Worklist
    route::resource('worklist', worklistController::class);

    Route::get('/report-loket', function () {
        return view ('loket.report');
    });

    Route::get('/result', function () {
        return view ('analyst.result-review');
    });

    Route::get('/dashboard-dok', function () {
        return view ('analyst.main-dokter');
    });

    Route::get('/quality-control', function () {
        return view ('analyst.quality-control');
    });
    Route::get('/daftar-qc', function () {
        return view ('analyst.daftar-qc');
    });
    Route::get('/history-qc', function () {
        return view ('analyst.history-qc');
    });
});



route::get('/autocomplete-icd10', [icd10Controller::class, 'geticd10'])->name('geticd10');
route::get('/previewpasien/{lab}', [pasienController::class, 'getDataPasien']);
