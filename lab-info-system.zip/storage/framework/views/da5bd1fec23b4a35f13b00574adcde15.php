
<div class="side tutup">
    <div class="logo-details">
      <i class='bx bx-book-open'></i>
      <span class="logo_name">AirBookLab</span>
    </div>
    <ul class="nav-links">
    <li>
        <div class="iocn-link">
        <a href="#">
            <i class='bx bx-desktop'></i>
            <span class="link_name">Loket</span>
        </a>
        <i class='bx bxs-chevron-down arrow' ></i>
        </div>
        <ul class="sub-menu">
        <li><a class="link_name" href="#">Loket</a></li>
        <li><a href="loket">Dashboard</a></li>
        <li><a href="data-pasien">Data Pasien</a></li>
        <li><a href="report-loket">Report</a></li>
        </ul>
    </li>
    <li>
        <div class="iocn-link">
        <a href="#">
            <i class='bx bxs-droplet' ></i>
            <span class="link_name">Laboratorium</span>
        </a>
        <i class='bx bxs-chevron-down arrow' ></i>
        </div>
        <ul class="sub-menu">
        <li><a class="link_name" href="#">Laboratorium</a></li>
        <li><a href="<?php echo e(route('demo.analyst.index')); ?>">Dashboard</a></li>
        <li><a href="<?php echo e(route('demo.spesiment.index')); ?>">Spesiment</a></li>
        <li><a href="<?php echo e(route('demo.worklist.index')); ?>">Worklist</a></li>
        <li><a href="result">Result Review</a></li>
        <li><a href="quality-control">QC</a></li>
        <li><a href="daftar-qc">Daftar QC</a></li>
        </ul>
    </li>
    <li>
        <div class="iocn-link">
            <a href="dashboard-dok">
                <i class='bx bx-book-content' ></i>
                <span class="link_name">Dokter</span>
            </a>
            <ul class="sub-menu">
            <li><a class="link_name" href="dashboard-dok">Dokter</a></li>
            </ul>
        </div>
    </li>
    
    <li>
    <div div class="profile-details">
        <div class="profile-content">
        <img src="<?php echo e(asset('image/1profile.png')); ?>" alt="1profile">
        </div>
        <div class="name-job">
        <div class="profile_name">
            <?php if(auth()->guard()->check()): ?>
                <?php echo e(Auth::user()->name); ?>

            <?php endif; ?>
        </div>
        <div class="job">
            <?php if(auth()->guard()->check()): ?>
                <?php echo e(Auth::user()->role); ?>

            <?php endif; ?>
        </div>
        </div>
        <a href="<?php echo e(route('logout')); ?>">
            <i class='bx bx-log-out' ></i>
        </a>
    </div>
    </li>
    </ul>
  </div>
<?php /**PATH C:\laragon\www\lab-info-system\resources\views/partials/sidebar.blade.php ENDPATH**/ ?>