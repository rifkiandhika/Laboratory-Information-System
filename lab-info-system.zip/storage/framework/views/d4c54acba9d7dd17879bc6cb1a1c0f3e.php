
<div class="content" id="scroll-content">
    <div class="container-fluid">
      <!-- Page Heading -->
      <div class="d-sm-flex  mt-3">
        <h1 class="h3 mb-0 text-gray-600">Daftar Pasien</h1>
      </div>

      <!-- Content Row -->
      <div class="row mt-3">

        <!-- Data Table -->
        <div class="col-xl-8 col-lg-7">
            <div class="card shadow mb-4">
                <!-- Card Header - Dropdown -->
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                    <h6 class="m-0 font-weight-bold" style="color: #96B6C5;">Daftar Pasien</h6>
                </div>
                <!-- Card Body -->
                <div class="card-body">
                  <div class="d-flex justify-content-between mb-3">
                    <form class="form-inline">
                      <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
                      <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
                    </form>
                  </div>
                  <div class="table-scroll" style="width: 100%; overflow-y: scroll; max-height: 550px;">
                  <table class="table table-striped">
                    <thead>
                      <tr>
                        <th scope="col">No</th>
                        <th scope="col">No RM</th>
                        <th scope="col">Nama</th>
                        <th scope="col">Tanggal Lahir(usia)</th>
                        <th scope="col">Jenis Kelamin</th>
                        <th scope="col">Alamat</th>
                        <th scope="col">Asal Poli</th>
                        <th scope="col">Dokter Pengirim</th>
                        <th scope="col">Action</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <th scope="row">1</th>
                        <td>01.01.02</td>
                        <td>Jeff Hardi</td>
                        <td>17-08-2020 / 3 tahun</td>
                        <td>Laki - Laki</td>
                        <td>Jalan Ijen</td>
                        <td>Umum</td>
                        <td>Dr. Soubndie</td>
                        <td><button href="#" class="btn btn-outline-info">Preview</button></td>
                      </tr>
                      <tr>
                        <th scope="row">2</th>
                        <td>01.01.03</td>
                        <td>Matt Hardi</td>
                        <td>17-08-2021 / 2 tahun</td>
                        <td>Laki - Laki</td>
                        <td>Jalan Sendiri</td>
                        <td>Umum</td>
                        <td>Dr. Soubndie</td>
                        <td><button href="#" class="btn btn-outline-info">Preview</button></td>
                      </tr>
                      <tr>
                        <th scope="row">3</th>
                        <td>01.01.05</td>
                        <td>Triple H</td>
                        <td>17-08-2018 / 5 tahun</td>
                        <td>Laki - Laki</td>
                        <td>Jalan Smekdon</td>
                        <td>Umum</td>
                        <td>Dr. Soubndie</td>
                        <td><button href="#" class="btn btn-outline-info">Preview</button></td>
                      </tr>
                      <tr>
                        <th scope="row">4</th>
                        <td>01.01.08</td>
                        <td>Stone Cold</td>
                        <td>17-08-2019 / 4 tahun</td>
                        <td>Laki - Laki</td>
                        <td>Jalan Smekdon</td>
                        <td>Umum</td>
                        <td>Dr. Soubndie</td>
                        <td><button type="button" class="btn btn-outline-info">Preview</button></td>
                      </tr>
                      <tr>
                        <th scope="row">5</th>
                        <td>01.01.09</td>
                        <td>John China</td>
                        <td>17-08-2016 / 6 tahun</td>
                        <td>Laki - Laki</td>
                        <td>Jalan Raw</td>
                        <td>Umum</td>
                        <td>Dr. Soubndie</td>
                        <td><button type="button" class="btn btn-outline-info">Preview</button></td>
                      </tr>
                      <tr>
                        <th scope="row">6</th>
                        <td>01.01.10</td>
                        <td>Undertikar</td>
                        <td>17-08-2010 / 13 tahun</td>
                        <td>Laki - Laki</td>
                        <td>Jalan Bloodring</td>
                        <td>Umum</td>
                        <td>Dr. Soubndie</td>
                        <td><button type="button" class="btn btn-outline-info">Preview</button></td>
                      </tr>
                      <tr>
                        <th scope="row">7</th>
                        <td>01.01.15</td>
                        <td>Tomingsek</td>
                        <td>17-08-2009 / 12 tahun</td>
                        <td>Laki - Laki</td>
                        <td>Jalan Capculacay</td>
                        <td>Umum</td>
                        <td>Dr. Soubndie</td>
                        <td><button type="button" class="btn btn-outline-info">Preview</button></td>
                      </tr>
                      <tr>
                        <th scope="row">8</th>
                        <td>01.01.15</td>
                        <td>Tomingsek</td>
                        <td>17-08-2009 / 12 tahun</td>
                        <td>Laki - Laki</td>
                        <td>Jalan Capculacay</td>
                        <td>Umum</td>
                        <td>Dr. Soubndie</td>
                        <td><button type="button" class="btn btn-outline-info">Preview</button></td>
                      </tr>
                      <tr>
                        <th scope="row">9</th>
                        <td>01.01.15</td>
                        <td>Tomingsek</td>
                        <td>17-08-2009 / 12 tahun</td>
                        <td>Laki - Laki</td>
                        <td>Jalan Capculacay</td>
                        <td>Umum</td>
                        <td>Dr. Soubndie</td>
                        <td><button type="button" class="btn btn-outline-info">Preview</button></td>
                      </tr>
                      <tr>
                        <th scope="row">10</th>
                        <td>01.01.15</td>
                        <td>Tomingsek</td>
                        <td>17-08-2009 / 12 tahun</td>
                        <td>Laki - Laki</td>
                        <td>Jalan Capculacay</td>
                        <td>Umum</td>
                        <td>Dr. Soubndie</td>
                        <td><button type="button" class="btn btn-outline-info">Preview</button></td>
                      </tr>
                      <tr>
                        <th scope="row">11</th>
                        <td>01.01.15</td>
                        <td>Tomingsek</td>
                        <td>17-08-2009 / 12 tahun</td>
                        <td>Laki - Laki</td>
                        <td>Jalan Capculacay</td>
                        <td>Umum</td>
                        <td>Dr. Soubndie</td>
                        <td><button type="button" class="btn btn-outline-info">Preview</button></td>
                      </tr>
                      <tr>
                        <th scope="row">12</th>
                        <td>01.01.15</td>
                        <td>Tomingsek</td>
                        <td>17-08-2009 / 12 tahun</td>
                        <td>Laki - Laki</td>
                        <td>Jalan Capculacay</td>
                        <td>Umum</td>
                        <td>Dr. Soubndie</td>
                        <td><button type="button" class="btn btn-outline-info">Preview</button></td>
                      </tr>
                    </tbody>
                    </table>
                  </div>
                </div>
            </div>
        </div>

        <!-- Priview -->
        <div class="col-xl-4 col-lg-5">
          <div class="card shadow mb-4">
              <!-- Card Header - Dropdown -->
              <div
                  class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                  <h6 class="m-0 font-weight-bold" style="color: #96B6C5;">Preview Pasien</h6>

              </div>
              <!-- Card Body -->
              <div class="card-body p-3">
                 <p class="h5 text-gray-800 mt-0">Identitas</p>
                  <form action="#" class="d-flex justify-content-between">
                    <div class="pasien">
                      <p class="h6 text-gray-600 mb-3">Pasien</p>
                      <table style="width: 100%">
                          <tr>
                              <td>No LAB</td>
                              <td>:</td>
                              <td class="pl-2">0341</td>
                          </tr>
                          <tr>
                            <td>No RM</td>
                            <td>:</td>
                            <td class="pl-2">012323</td>
                          </tr>
                          <tr>
                              <td>Nama</td>
                              <td>:</td>
                              <td class="pl-2">John China</td>
                          </tr>
                          <tr>
                            <td>Gender</td>
                            <td>:</td>
                            <td class="pl-2">Tidak Disebutkan</td>
                          </tr>
                          <tr>
                            <td >Umur</td>
                            <td>:</td>
                            <td class="pl-2">20 tahun</td>
                          </tr>
                          <tr>
                            <td >Alamat</td>
                            <td>:</td>
                            <td class="pl-2">Porong</td>
                          </tr>
                          <tr>
                            <td >Jenis Pasien</td>
                            <td>:</td>
                            <td >Platinum</td>
                          </tr>
                          <tr>
                            <td >Ruangan</td>
                            <td>:</td>
                            <td>Abu Thalib</td>
                          </tr>
                      </table>
                    </div>
                    <div class="dokter">
                      <p class="h6 text-gray-600 mb-3">Dokter</p>
                      <table style="width: 100%">
                          <tr>
                              <td >Nama Dokter</td>
                              <td>:</td>
                              <td>dr. bande</td>
                          </tr>
                          <tr>
                            <td >Ruangan</td>
                            <td>:</td>
                            <td>Abu Thalib</td>
                          </tr>
                          <tr>
                              <td >Telp</td>
                              <td>:</td>
                              <td>0812313</td>
                          </tr>
                          <tr>
                            <td >Email</td>
                            <td>:</td>
                            <td>gmail.com</td>
                          </tr>
                          <tr>
                            <td >Diagnosa</td>
                            <td>:</td>
                            <td>mati suri</td>
                          </tr>
                      </table>
                    </div>
                    <hr>
                  </form>
                  <div class="mt-4 text-center small">
                      <span class="mr-2">
                          <i class="fas fa-circle text-primary"></i> Direct
                      </span>
                      <span class="mr-2">
                          <i class="fas fa-circle text-success"></i> Social
                      </span>
                      <span class="mr-2">
                          <i class="fas fa-circle text-info"></i> Referral
                      </span>
                  </div>
              </div>
          </div>
      </div>

    </div>


    </div>
  </div>
<?php /**PATH C:\laragon\www\lab-info-system\resources\views/loket/daftar-pasien.blade.php ENDPATH**/ ?>